package fr.dauphine.miageif.msa.Microservice;

import org.springframework.data.jpa.repository.JpaRepository;
import java.util.List;

public interface OperationRepository extends JpaRepository<Operation, Long>{
    List<Operation> findAll();
}

