package fr.dauphine.miageif.msa.Microservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class LounesYacineApplication {

	public static void main(String[] args) {
		SpringApplication.run(LounesYacineApplication.class, args);
	}

}

